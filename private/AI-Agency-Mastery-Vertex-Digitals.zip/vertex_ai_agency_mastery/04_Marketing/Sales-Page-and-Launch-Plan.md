# Vertex Digital — AI Agency Mastery
## Landing page draft

### Headline
Turn AI skills into a practical service business plan.

### Subheadline
A beginner-friendly ebook and implementation toolkit to help you choose an AI service, build a portfolio demo, approach relevant prospects, and deliver projects professionally.

### What you'll learn
- Choose a focused service and customer group.
- Build a demonstrable portfolio without pretending demo work is client work.
- Package and price a service using costs, scope, and customer needs.
- Research prospects and write personalized outreach.
- Run discovery conversations, prepare proposals, and deliver projects.
- Track costs, support obligations, and recurring service work.

### Included
- 12-chapter searchable PDF ebook.
- Niche selection scorecard and offer builder.
- Prospect tracker and outreach scripts.
- Pricing calculator and proposal template.
- Client onboarding, QA, and handover checklists.
- 30-day implementation planner.

### Important
This product provides education and templates. It does not guarantee clients, revenue, or business outcomes. Results depend on execution, market demand, sales, delivery quality, and other factors. Tool availability, pricing, and features may change.

## 30-day launch plan

### Days 1–7: Validate
1. Interview 10–15 target readers.
2. Share the table of contents and a sample chapter.
3. Test interest in a clearly described beta offer.

### Days 8–21: Produce
1. Write and fact-check the 12 chapters.
2. Build workbook and templates.
3. Design the ebook after content is stable.
4. Test formulas, links, prompts, and downloads.

### Days 22–25: Set up sales
1. Build a landing page and checkout.
2. Confirm supported countries, payouts, platform fees, and tax handling.
3. Publish terms, privacy information, and refund policy.
4. Test purchase and delivery end-to-end.

### Days 26–30: Launch and improve
1. Publish practical demonstrations.
2. Offer a useful free checklist or sample chapter.
3. Use permitted creator/community collaborations.
4. Collect questions and feedback; fix friction before scaling promotion.

## Content themes
- Three AI services a beginner can learn to deliver.
- Build a demo website and label it honestly as a demo.
- How to personalize a prospecting message.
- How to calculate the cost of an AI automation project.
- Why selling ten services before mastering one creates delivery problems.
- A preview of the niche scorecard.

## Metrics
Track landing page visits, sample downloads, checkout starts, completed purchases, refunds, support questions, customer feedback, and net contribution after fees, taxes, refunds, marketing, and other costs.
