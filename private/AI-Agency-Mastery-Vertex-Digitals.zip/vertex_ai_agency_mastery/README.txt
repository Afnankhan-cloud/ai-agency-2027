VERTEX DIGITAL — AI AGENCY MASTERY
Starter production package

Contents
- 01_Ebook/Vertex-AI-Agency-Mastery-Production-Blueprint.docx: editable production blueprint
- 01_Ebook/Vertex-AI-Agency-Mastery-Production-Blueprint.pdf: PDF version of the blueprint
- 01_Ebook/AI-Agency-Mastery-Manuscript-and-Production-Guide.md: detailed writing/production guide
- 02_Workbook/Vertex-Agency-Launch-Workbook.xlsx: niche scorecard, pricing calculator, prospect tracker, 30-day planner
- 03_Templates/Vertex-Editable-Agency-Templates.docx: editable offer, outreach, discovery, proposal, QA and reporting templates
- 04_Marketing/Sales-Page-and-Launch-Plan.md: draft landing page and launch plan

Important
This is a production starter package, not a finished 90–120 page consumer ebook. The blueprint and manuscript scaffold specify the content that must be written, reviewed, designed, and tested before the product is sold. No earnings or client outcomes are guaranteed. Review applicable laws, tool terms, copyright, tax, privacy, and platform policies before publishing.
